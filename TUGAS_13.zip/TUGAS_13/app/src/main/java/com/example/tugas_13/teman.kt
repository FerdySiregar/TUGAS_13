package com.example.tugas_13

data class teman(
    val id: Int = 0,
    val nama: String,
    val sekolah: String,
    val hobi: String
)
